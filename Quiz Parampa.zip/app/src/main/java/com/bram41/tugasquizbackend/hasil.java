package com.bram41.tugasquizbackend;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class hasil extends AppCompatActivity {
    TextView hasil_txt;
    int hasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil);

        hasil_txt = findViewById(R.id.hasil);

        Bundle b = getIntent().getExtras();

        int score= b.getInt("score");

        hasil_txt.setText(""+score);
    }
    public void ulang(View view){
        Intent intent = new Intent(hasil.this, soal.class);
        startActivity(intent);
    }
}
